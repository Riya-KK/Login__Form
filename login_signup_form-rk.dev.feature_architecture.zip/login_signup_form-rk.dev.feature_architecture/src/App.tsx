

// import Rout from "./components/Rout"

// const App = () => {
//   return (
//     <>
//     <Rout/>
//     </>

//   )
// }

// export default App
// import React from 'react'

import { Routes , Route} from "react-router-dom";
import Login from "./pages/login";
import Dashboard from "./pages/dashboard";
import UserDetail from "./pages/userDetail";

const App = () => {
  return (
   <>
   
    <Routes>
    <Route index element={<Login/>}></Route>
    <Route path="/dasboard" element={<Dashboard/>}></Route>
    <Route path="/ad/:id" element={<UserDetail/>}></Route>
    </Routes>
 
   </>
  )
}

export default App;