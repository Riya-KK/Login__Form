
// import ReactDOM from 'react-dom/client'
// import App from './App.tsx'
// import { BrowserRouter } from 'react-router-dom'



// ReactDOM.createRoot(document.getElementById('root')!).render(
//   <BrowserRouter>
//     <App />
//   </BrowserRouter>,
// )
// import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App.tsx'
import { BrowserRouter } from 'react-router-dom'
// import './index.css'
// import LoginForm from './components/LoginForm.tsx'

ReactDOM.createRoot(document.getElementById('root')!).render(

  // <React.StrictMode>
  //   <App />
  //   {/* <LoginForm/> */}
  // </React.StrictMode>

  
  <BrowserRouter>
  <App/>
  </BrowserRouter>
  ,
)
