// // import React from 'react'
// import "../styles/Header.css";
// import LogoutButton from "../components/LogoutButton";
// import BackSymbol from "./BackSymbol";


// const Header = () => {

// const isResourceDetails=true;

//   return (
//     <>
//       <div className="header">

//         <div className="back">
//           {isResourceDetails == true ?<BackSymbol /> : null}
//           <img
//             src="\src\assets\images\logo.png"
//             alt="Logo"
//             className="logicease"
//           />

//         </div>

//         <div>
//           <LogoutButton />
//         </div>
//       </div>
//     </>
//   );
// };

// export default Header;

// import React from 'react';
import "../styles/Header.css";
import LogoutButton from "./LogoutButton";
import BackIcon from "./BackIcon";

const Header = ({ isResourceDetails }) => {
  return (
    <>
      <div className="header">
        <div className="back">
          {isResourceDetails ? <BackIcon /> : null}
          <img
            src="\src\assets\images\logo.png"
            alt="Logo"
            className="logicease"
          />
        </div>
        <div>
        {/* {isResourceDetails ? <LogoutButton /> : null} */}
          <LogoutButton />
        </div>
      </div>
    </>
  );
};

export default Header;
