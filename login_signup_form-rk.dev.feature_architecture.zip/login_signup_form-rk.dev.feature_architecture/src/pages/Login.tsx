import React, { useState } from "react";
import "../styles/login.css";
import "../styles/index.css";
import Dashboard from "./dashboard";

const Login: React.FC = () => {
  const [username, setUsername] = useState<string>("");
  const [password, setPassword] = useState<string>("");
  const [loginSuccess, setLoginSuccess] = useState<boolean>(false);

  const handleUsernameChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setUsername(e.target.value);
  };

  const handlePasswordChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setPassword(e.target.value);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    try {
      const response = await fetch("https://dummyjson.com/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          username: username,
          password: password,
        }),
      });

      if (response.ok) {
        // Set loginSuccess to true on successful login
        setLoginSuccess(true);

        sessionStorage.setItem("username", "kminchelle");
        alert("Login Successfully)");
      } else {
        alert("Login Failed");
      }
    } catch (error) {
      console.error("API request error:", error);
      alert("An error occurred during login");
    }
  };

  // If loginSuccess is true, render the Dashboard component directly
  if (loginSuccess) {
    return <Dashboard />;
  }

  return (
    <div className="log">
      <div className="login-form-container">
        <div className="img-container">
          <img src="\src\assets\images\logo.png" alt="Logo" className="logo" />
        </div>
        <form onSubmit={handleSubmit}>
          <div className="form-content">
            <div className="form-group">
              <input
                type="text"
                id="username"
                placeholder="Username"
                value={username}
                onChange={handleUsernameChange}
                required
              />
            </div>
            <div className="form-group">
              <input
                type="password"
                id="password"
                value={password}
                placeholder="Password"
                onChange={handlePasswordChange}
                required
              />
            </div>
            <button type="submit" className="login-button">
              Login
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default Login;
