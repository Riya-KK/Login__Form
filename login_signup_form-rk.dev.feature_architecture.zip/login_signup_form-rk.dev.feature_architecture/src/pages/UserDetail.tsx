import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import axios from "axios";
import Header from "../components/Header";
import "../styles/UserDetails.css";

interface Employee {
  id: number;
  firstName: string;
  lastName: string;
  age: number;
  gender: string;
  email: string;
  image: string;
  phone: number;
  salary: 1;
  address: {
    city: string;
    address: string;
  };
  university: string;
  birthDate: string;
  height: number;
  weight: number;
}

const UserDetail = () => {
   const storedUsername = sessionStorage.getItem("username");
  
   if (storedUsername === "kminchelle") {

  const { id } = useParams(); // Get the user's id from the URL

  const [user, setUser] = useState<Employee | null>(null);
  const isResourceDetails = true;

  // Define Employee type or interface

  useEffect(() => {
    axios
      .get(`https://dummyjson.com/users/${id}`) // Replace with your actual API URL
      .then((res) => {
        // Assuming the API response contains the user's details
        setUser(res.data);
        console.log(res);
      })
      .catch((err) => console.log(err));
  }, [id]);

  return (
    <div>
      {user && (
        <div>
          <div className="specific">
            <Header isResourceDetails={isResourceDetails} />

            <h1>User Details</h1>
            {/* <p>
            {user.firstName} {user.lastName}
          </p> */}
            {/* Display other user details here */}

            <div className="data">
              <div className="user-image">
                <p>
                  {/* <img
                    src=" https://robohash.org/doloremquesintcorrupti.png"
                   /> */}
                  <img src={user.image} alt="" />
                </p>
              </div>

              <div className="user-data">
                <p>
                  <strong>Id:</strong> &nbsp; {user.id}
                </p>
                <p>
                  <strong>FirstName:</strong> &nbsp; {user.firstName}
                </p>
                <p>
                  <strong>LastName:</strong> &nbsp; {user.lastName}
                </p>
                <p>
                  <p>
                    <strong>Address:</strong> &nbsp; {user.address.address}
                  </p>
                  <strong>Age:</strong> &nbsp; {user.age}
                </p>
                <p>
                  <strong>Gender:</strong> &nbsp; {user.gender}
                </p>
                <p>
                  <strong>Date Of Birth:</strong> &nbsp; {user.birthDate}
                </p>
                <p>
                  <strong>E-mail:</strong> &nbsp; {user.email}
                </p>
                <p>
                  <strong>Contact Number:</strong> &nbsp; {user.phone}
                </p>
                <p>
                  <strong>University:</strong> &nbsp; {user.university}
                </p>
                <p>
                  <strong>Height:</strong> &nbsp; {user.height}
                </p>
                <p>
                  <strong>Weight:</strong> &nbsp; {user.weight}
                </p>
                <p>
                  <strong>City:</strong> &nbsp; {user.address.city}
                </p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}else{
   alert("Access Denied");
}
};
export default UserDetail;
