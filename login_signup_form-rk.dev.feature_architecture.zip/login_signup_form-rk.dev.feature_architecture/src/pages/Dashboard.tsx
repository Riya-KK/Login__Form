import { useEffect, useState } from "react";
import axios from "axios";
import "../styles/dashboard.css";
import Header from "../components/Header";
import { Link } from "react-router-dom";
interface Employee {
  id: number;
  firstName: string;
  lastName: string;
  age: number;
  gender: string;
  email: string;
  image: string;
  phone: number;
  salary: number;
  address: string;
  university: string;
  birthDate: string;
  height: number;
  weight: number;
}
const Dashboard = () => {
  const storedUsername = sessionStorage.getItem("username");
  if (storedUsername !== "kminchelle") {
    alert("Access Denied");
  } else {
    const [userData, setUserData] = useState<Employee[]>([]);
    const [page, setPage] = useState(1);
    const usersPerPage = 8;
    useEffect(() => {
      const fetchData = async () => {
        try {
          const res = await axios.get(
            `https://dummyjson.com/users?limit=${usersPerPage}&page=${page}`
          );
          const fetchedData = res.data.users;
          setUserData((prevData) => [...prevData, ...fetchedData]);
        } catch (err) {
          console.error(err);
        }
      };
      fetchData();
    }, [page]);
    const handleScroll = () => {
      if (
        window.innerHeight + document.documentElement.scrollTop ===
        document.documentElement.scrollHeight
      ) {
        // Calculate the next page
        const nextPage = Math.floor(userData.length / usersPerPage) + 1;
        if (nextPage > page) {
          setPage(nextPage);
        }
      }
    };
    useEffect(() => {
      window.addEventListener("scroll", handleScroll);
      return () => {
        window.removeEventListener("scroll", handleScroll);
      };
    }, [userData]);
    return (
      <>
        <div>
          <Header isResourceDetails={false} />
        </div>
        <div>
          <p className="emp">User Details</p>
        </div>
        <div className="API-data">
          <div className="tabular-data">
            <table>
              <thead>
                <tr>
                  <th>Id</th>
                  <th>Name</th>
                  <th>Email</th>
                  <th>Photo</th>
                  <th>Details</th>
                </tr>
              </thead>
              <tbody>
                {userData.map((user) => (
                  <tr key={user.id}>
                    <td>{user.id}</td>
                    <td>
                      {user.firstName} {user.lastName}
                    </td>
                    <td>{user.email}</td>
                    <td>
                      <img
                        src={user.image}
                        className="table-images"
                        alt={`User ${user.id}`}
                      />
                    </td>
                    <td>
                      <Link to={`/ad/${user.id}`}>View Details</Link>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </>
    );
  }
};
export default Dashboard;
